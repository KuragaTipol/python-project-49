#!/usr/bin/env python3

def main():
    print('poetry run brain games')
    print('Welcome to the Brain Games!')

if __name__ == "__main__":
    main()
