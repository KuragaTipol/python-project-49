### Hexlet tests and linter status:
[![Actions Status](https://github.com/KuragaTipol/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/KuragaTipol/python-project-49/actions)

acsiinema link 'brain-even': (https://asciinema.org/a/ydlIyQdFfVp2fbzpLD0uLCsuG)

asciinema link 'brain-calc': (https://asciinema.org/a/2inOzOHHkV46umnle3Bumg3NQ)

asciinema link 'brain-gcd': (https://asciinema.org/a/CL1cCb1902Ub0sKPQLK12IPyy)
