### Hexlet tests and linter status:
[![Actions Status](https://github.com/KuragaTipol/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/KuragaTipol/python-project-49/actions)

acsiinema link: (https://asciinema.org/a/ydlIyQdFfVp2fbzpLD0uLCsuG)
